Language Used : Python3
Run Command : python3 20CS60R40_VC4.py
Approximate Time Taken : 3-8 seconds.
Note: The above time includes the downloading of dataset and running all the required function .
